<section class="content-header">
  <h1>Beranda</h1>
</section>

<section class="content">
  <div class="row">
    <div class="col-lg-3 col-6">      
      <!-- small box -->
      <div class="small-box bg-warning">
        <div class="inner">
          <h3>150</h3>

          <p>Penelitian</p>
        </div>
        <div class="icon">
          <i class="ion ion-search"></i>
        </div>
        <a href="penelitian.php" class="small-box-footer text-dark">Selengkapnya <i class="fas fa-arrow-circle-right"></i></a>
      </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-success">
        <div class="inner">
          <h3>53</h3>

          <p>Publikasi</p>
        </div>
        <div class="icon">
          <i class="ion ion-ios-book"></i>
        </div>
        <a href="#" class="small-box-footer">Selengkapnya <i class="fas fa-arrow-circle-right"></i></a>
      </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-warning">
        <div class="inner">
          <h3>124</h3>

          <p>Pengabdian Masyarakat</p>
        </div>
        <div class="icon">
          <i class="ion ion-android-hand"></i>
        </div>
        <a href="#" class="small-box-footer">Selengkapnya <i class="fas fa-arrow-circle-right"></i></a>
      </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-danger">
        <div class="inner">
          <h3>75</h3>

          <p>Dosen Terdaftar</p>
        </div>
        <div class="icon">
          <i class="ion ion-android-person-add"></i>
        </div>
        <a href="#" class="small-box-footer">Selengkapnya <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->

     
</section>
    <!-- /.content -->

<script>
  $("#dashboard1").addClass('active');
</script>