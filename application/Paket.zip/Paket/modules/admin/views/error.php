<!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-body">
            <div class="col-md-12">
              <h4><i class="fa fa-warning"></i> &nbsp; Error!</h4>
            </div>           
          </div>
        </div>
      </div>      

      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-12">

          <h4><?=$error; ?></h4>
           
          </div>         
        </div>

       
      </div>
      <!-- /.row -->

     

     
    </section>
 